package recur;

import java.awt.Color;
import java.awt.Graphics;

public class HShape extends AbstractShape {

    public HShape() {
        super(7);
    }

    public void draw() {
        throw new UnsupportedOperationException("Not supported yet.");
        // To change body of generated methods, choose Tools | Templates.
    }

    public void update(int value) {
        throw new UnsupportedOperationException("Not supported yet.");
        // To change body of generated methods, choose Tools | Templates.
    }

    public void createChildren() {
    }

    @Override
    public void draw(Graphics g) {
        // TODO Auto-generated method stub

    }
}
           
